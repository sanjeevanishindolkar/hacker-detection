//----------------------------------------------------------------------------
//
// Module:      SimpleTextColumn.java      
//
// Description: Object that represents a single result set column
//
// Author:      Karl Moss
//
// Copyright:   (C) 1996 Karl Moss.  All rights reserved.
//              You may study, use, modify and distribute this example
//              for any purpose, provided that this copyright notice
//              appears in all copies.  This example is provided WITHOUT
//              WARRANTY either expressed or implied.
//----------------------------------------------------------------------------

package jdbc.SimpleText;

public class SimpleTextColumn
    extends        Object
    implements     Cloneable
{
    //------------------------------------------------------------------------
    // Constructor
    //------------------------------------------------------------------------

    public String toString() {
        return("schema=<"+schemaName+">Table Name=<"+tableName+">Column name=<"+name+">type=<"+type+">precision=<"+precision+">colNo=<"+colNo+"> DisplayColumn=<"+displayColumn+">");
    }
    public SimpleTextColumn(
        String name,
        int type,
        int precision)
    {
        this.name = name;
        this.type = type;
        this.precision = precision;
    }

    public SimpleTextColumn(
        String name,
        int type)
    {
        this.name = name;
        this.type = type;
        this.precision = 0;
    }

    public SimpleTextColumn(
        String name)
    {
        this.name = name;
        this.type = 0;
        this.precision = 0;
    }
    
    public Object clone() {
	SimpleTextColumn stc = new SimpleTextColumn(name,type,precision);
	stc.searchable = searchable;
	stc.colNo = colNo;
	stc.displaySize = displaySize;
	stc.displayColumn = displayColumn;
	stc.typeName = typeName;
	stc.tableName = tableName;
	stc.schemaName = schemaName;
	return stc;
    }

    public String schemaName;
    public String tableName;
    public String name;
    public int type;
    public int precision;
    public boolean searchable;
    public int colNo;
    public int displayColumn = -1;
    public int displaySize;
    public String typeName;
    public boolean usejoin = false;
} 

